<?php

// Requires the file that contains the definition of the VideoJsViewerPlugin class
require_once('VideoJsViewerPlugin.inc.php');

// Creates a new instance of the VideoJsViewerPlugin and returns it
return new VideoJsViewerPlugin();

?>